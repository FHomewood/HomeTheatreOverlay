------Home Theatre Overlay------
Author: Frankie Homewood
www.github.com/fhomewood
Free for use and alteration

---------------Using HTO---------------
To run the program, run Hotkey.exe, this will open the overlay (overlay.exe) everytime Shift - Num1 is pressed
Consider adding this to startup programs or quick access.

-------------Customisation-------------
The program is designed to be modular so you can edit the charm names and files and add as many as you like,
to do this open the @\Charms file and make a new folder, the Charm name is the folder name (ignoring the first two characters for ordering purposes)
then add three files: Background.png, Foreground.png, Shortcut.lnk

You can edit these files to give the correct icon and hover image as well as ensuring the shortcut links to the correct .exe